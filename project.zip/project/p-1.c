#include<stdio.h>
main(){
	int c,f;
	
	printf("Enter your deggree cecuis:");
	scanf("%d",&c);
	
	f=(c * 9/5)+32;
	printf("%d",f);
	
}
